#  Backend

### To start project please install dependencies
    yarn

### Then start server
    yarn start:dev


